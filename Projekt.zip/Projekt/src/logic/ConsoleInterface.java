package logic;

public class ConsoleInterface {

    private Travel travel = new Travel();

    ConsoleInterface(){
        run();
    }

    private void run(){

    }

}
